package com.cts.hackathon;

import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletException;
import javax.swing.text.Utilities;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.vision.v1.Vision;
import com.google.api.services.vision.v1.VisionRequestInitializer;
import com.google.api.services.vision.v1.model.AnnotateImageRequest;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesRequest;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesResponse;
import com.google.api.services.vision.v1.model.Feature;
import com.google.api.services.vision.v1.model.Image;
import com.google.api.services.vision.v1.model.ImageContext;

public class TextExtractionService {
	

private static final String CLOUD_VISION_API_KEY = "AIzaSyD6P2tDWyzEtq3QcYTLx5i5at14Y9uYd10";
	
	
	public BatchAnnotateImagesResponse getReponseFromVisionAPI(InputStream inputStream,List<String> langList) {
		
		byte[] data;
		BatchAnnotateImagesResponse visionResponse = null;
		try {
			data = UtilityClass.toByteArray(inputStream);
	
		  HttpTransport httpTransport;
		
				httpTransport = GoogleNetHttpTransport.newTrustedTransport();

				JsonFactory jsonFactory = GsonFactory.getDefaultInstance();
				VisionRequestInitializer initializer = new VisionRequestInitializer(CLOUD_VISION_API_KEY);

				Vision.Builder builder = new Vision.Builder(httpTransport, jsonFactory, null);
				builder.setApplicationName("Liberty Hackathon App");
				builder.setVisionRequestInitializer(initializer);

				Vision vision = builder.build();	   			
		    
		   
		    // Create the image request
			AnnotateImageRequest imageRequest = new AnnotateImageRequest();
			Image image = new Image();
			image.encodeContent(data);
			imageRequest.setImage(image);			
				
			// Add the features we want
			Feature docTextdetection = new Feature();
			docTextdetection.setType("DOCUMENT_TEXT_DETECTION");
		    docTextdetection.setMaxResults(10);
			imageRequest.setFeatures(Collections.singletonList(docTextdetection));
			
			ImageContext imageContext = new ImageContext();
			imageContext.setLanguageHints(langList);
			imageRequest.setImageContext(imageContext);			
			

			// Batch and execute the request
			BatchAnnotateImagesRequest requestBatch = new BatchAnnotateImagesRequest();
			requestBatch.setRequests(Collections.singletonList(imageRequest));
			visionResponse = vision.images().annotate(requestBatch)
					.setDisableGZipContent(true).execute();
		}
			catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		
	
	 catch (GeneralSecurityException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return visionResponse;
	}

}
