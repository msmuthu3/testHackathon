package com.cts.hackathon;


import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.io.FilenameUtils;

import com.google.api.services.vision.v1.model.BatchAnnotateImagesResponse;
import com.google.api.services.vision.v1.model.TextAnnotation;

@WebServlet(
    name = "HelloAppEngine",
    urlPatterns = {"/getData"}
)
@MultipartConfig
public class HelloAppEngine extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	  
  @Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) 
      throws IOException {	  
	    
	 
			InputStream fileContent = null;
			BatchAnnotateImagesResponse visionResponse = null;
			String forwardJSP = null;
			InputStream compressedDataInputStream = null;
			
			String requestType = request.getParameter("requestType");
			//System.out.println("requestType>>>>" + requestType);
			
			String langSelect = request.getParameter("langSelect");
			System.out.println("langSelect>>> "+ langSelect);
			List<String> langList = new ArrayList<>();
			langList.add(langSelect);
			
			 try {
			
			      Part filePart = request.getPart("fileInput"); // Retrieves <input type="file" name="fileInput">
			      
			      String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); 
			     String fileExtension = FilenameUtils.getExtension(fileName);
			      
			      if(fileExtension.equalsIgnoreCase("TIF")||fileExtension.equalsIgnoreCase("TIFF")) {
			    	  
			    	  File tempFile = File.createTempFile("convTiff", ".png");
			    	   
			    	  try{
			    			final BufferedImage tif = ImageIO.read(filePart.getInputStream());
			    			 ImageIO.write(tif, "png", tempFile);
			    			 }
			    			 catch (IOException ex) {
			    		          System.out.println("not working");
			    		        }				    	  
			    	 
			    	  fileContent =  new FileInputStream(tempFile);
			    	  tempFile.deleteOnExit();
			      }
			      
			      else {
			      fileContent = filePart.getInputStream();	
			      }
			      
			
			    } 
			 
			 catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					
			// System.out.println("fileContent>>>>>>>>" + fileContent);
			 
				if ("chequeRequest".equalsIgnoreCase(requestType)) {
					System.out.println("No compression if");
					compressedDataInputStream = fileContent;
				}else {
					System.out.println("compression done");
					//compressedDataInputStream = fileContent;  //for testing cheque
			        compressedDataInputStream =  UtilityClass.compressImageFile(fileContent);
				}
		 //  System.out.println("apiDataInputStream >>>>>>" + apiDataInputStream);
		   
		   //call vision API service
		   TextExtractionService serviceRequest = new TextExtractionService();
		  
		   try {
		   visionResponse = serviceRequest.getReponseFromVisionAPI(compressedDataInputStream,langList);		 
			 
			if ("chequeRequest".equalsIgnoreCase(requestType)) {
				 ChequeModel chequeData = extractForCheque(visionResponse);
				 request.setAttribute("imgData", chequeData);
				 forwardJSP = "/jsp/chequeResponse.jsp";
				 
			}
			else {
		   
		       String[] fullTextArray = extractResults(visionResponse);
		       request.setAttribute("imgData", fullTextArray);
		  	 forwardJSP = "/jsp/imageResponse.jsp";
		   
			}										
			
				getServletContext().getRequestDispatcher(forwardJSP).forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				request.setAttribute("errors", "Image cannot be processed at this time .Please try again later !");
			}	
		   catch (Exception e) {
			   
			   forwardJSP = "/jsp/index.jsp";
				// TODO Auto-generated catch block
			   request.setAttribute("errors", "Image cannot be processed at this time .Please try again later !");
			   try {
				getServletContext().getRequestDispatcher(forwardJSP).forward(request, response);
			} catch (ServletException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}	
		 
  }
  

public  String[] extractResults (BatchAnnotateImagesResponse response){
	 
	TextAnnotation fullText = response.getResponses().get(0).getFullTextAnnotation();
	
	//System.out.println("FULLTEXT>>>>  " + fullText.getText());
	
	//return fullText.getText();	

	//>>>>>>> converting to Java objects for reference
	String []values = fullText.getText().split("\n");	
	
	
	return values;
		
	// >>>>>> write to a file for reference if you want
	//writeResponseToaFile(fullText);
	 
	
}

public ChequeModel extractForCheque(BatchAnnotateImagesResponse response) {
	
	TextAnnotation fullText = response.getResponses().get(0).getFullTextAnnotation();
	String []values = fullText.getText().split("\n");
    ChequeModel cheque=new ChequeModel();
	
	for ( String val : values){				
		// System.out.println("val>>>>> " + val);
		
			if (val.contains("No.")){
			
			String cheqNo = val.substring(val.indexOf(".")+1, val.length());
			
			cheque.setChequeNo(cheqNo);
			
		   }		
			else if (val.contains("Date")){
			
			String date = val.substring(val.indexOf("e")+1, val.length());
			
			cheque.setDate(date);
			}
			
			else if (val.contains("$")){
				
				String amount = val.substring(val.indexOf("$"),val.indexOf(".")+3);
				
				cheque.setAmount(amount);
			
	     	}
             else if (val.contains("Bank")){				
							
				cheque.setBankName(val);			
		     }
	}
	
	return cheque;
}


}