package com.cts.hackathon;

import java.io.*;
import java.util.*;
import java.awt.image.*;

import javax.imageio.*;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.ImageOutputStream;

import com.google.api.services.vision.v1.model.TextAnnotation;

public class UtilityClass {
	
	private static final int MAX_BUFFER_LENGTH = 16384; 
	
	/** Returns the byte array. */
	public static byte[] toByteArray(InputStream is) throws IOException {
	  ByteArrayOutputStream buffer = new ByteArrayOutputStream();
	  int nRead;
	  byte[] bytes = new byte[MAX_BUFFER_LENGTH];

	  while ((nRead = is.read(bytes, 0, bytes.length)) != -1) {
	    buffer.write(bytes, 0, nRead);
	  }

	  buffer.flush();
	  return buffer.toByteArray();
	}
	
	public static void writeResponseToaFile(TextAnnotation fullText){
		
		 File reponseFile=new File("D:\\Users\\Muthu Raman\\git\\FSD-QuoteInsuranceAPP\\com.google.vision\\src\\main\\java\\visioncloud\\response.txt");
		 try {
		    FileWriter fileWriter = new FileWriter(reponseFile);	
			fileWriter.write(fullText.getText());
			fileWriter.flush();
			 fileWriter.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  
	}
	
	
	public static InputStream compressImageFile(InputStream is) {
		
		//File input = new File("Z:\\hackathon\\bigimage.jpg");
	      BufferedImage image;
	      
	      InputStream compInputstream = null ;
	   
		try {
			image = ImageIO.read(is);
			
			File tempFile2 = File.createTempFile("compressTemp", "jpg");			
		
			OutputStream os = new FileOutputStream(tempFile2);

			  Iterator<ImageWriter>writers = ImageIO.getImageWritersByFormatName("jpg");
			  ImageWriter writer = (ImageWriter) writers.next();

			  ImageOutputStream ios = ImageIO.createImageOutputStream(os);
			  writer.setOutput(ios);

			  ImageWriteParam param = writer.getDefaultWriteParam();
			  // Check if canWriteCompressed is true
			  if(param.canWriteCompressed()) {
			     param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
			     param.setCompressionQuality(0.45f);
			  }
			  // End of check
			  writer.write(null, new IIOImage(image, null, null), param);
	      
		  os.close();
	      ios.close();
	      writer.dispose();
	      
	      compInputstream = new FileInputStream(tempFile2);      
	      
	      tempFile2.deleteOnExit();
		
	}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		return compInputstream ;
		
	}
}
