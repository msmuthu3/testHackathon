package com.cts.hackathon;

public class ChequeModel {
	
	
	private String accountNo;
	private String amount;
	private String accoutholder;
	private String IFScode;
	
	
	private String bankName;
	private String date;
	private String chequeNo;
	private String chequeBearer;
	
	

	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	
	public String getAccountNo() {
		return accountNo;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	public String getAccoutholder() {
		return accoutholder;
	}
	public void setAccoutholder(String accoutholder) {
		this.accoutholder = accoutholder;
	}
	public String getChequeBearer() {
		return chequeBearer;
	}
	public void setChequeBearer(String chequeBearer) {
		this.chequeBearer = chequeBearer;
	}
	public String getIFScode() {
		return IFScode;
	}
	public void setIFScode(String iFScode) {
		IFScode = iFScode;
	}
	
	
	

}
