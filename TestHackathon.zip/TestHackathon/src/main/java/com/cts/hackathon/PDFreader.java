package com.cts.hackathon;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.io.FilenameUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

@WebServlet(
	    name = "PDFreader",
	    urlPatterns = {"/getPDFtext"}
	)
@MultipartConfig
public class PDFreader extends HttpServlet{
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	  public void doPost(HttpServletRequest request, HttpServletResponse response) 
	      throws IOException {	
		 
		 String [] pdfTextData = null;
		 String forwardJSP = null;
		 try {
				
		      Part filePart = request.getPart("fileInput"); // Retrieves <input type="file" name="fileInput">
		      
		      String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); 
		     String fileExtension = FilenameUtils.getExtension(fileName);
		      
		      if(fileExtension.equalsIgnoreCase("PDF")) {		    	  
		    	  PDDocument doc = PDDocument.load(filePart.getInputStream());
				   String pdfResponse =  new PDFTextStripper().getText(doc);
				   pdfTextData = pdfResponse.split("\n");
				   request.setAttribute("pdfData", pdfTextData);
				   forwardJSP = "/jsp/pdfResponse.jsp";
		      }		      
		      else {
		    	  forwardJSP = "/jsp/pdfFileUpload.jsp";
		    	  request.setAttribute("errors", "Please use a file of PDF format with .pdf extension!");
		      }
		 		        				 				 
			 getServletContext().getRequestDispatcher(forwardJSP).forward(request, response);
			 } catch (ServletException e) {
				// TODO Auto-generated catch block
				request.setAttribute("errors", "PDF cannot be processed at this time .Please try again later !");
			 }	
		    catch (Exception e) {
			   
			   forwardJSP = "/jsp/index.jsp";
				// TODO Auto-generated catch block
			   request.setAttribute("errors", "PDF cannot be processed at this time .Please try again later !");
			   try {
				getServletContext().getRequestDispatcher(forwardJSP).forward(request, response);
			} catch (ServletException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}	
		    
	 }

}
