
function spinnerStart(){     
	var fileVerify = document.getElementById("fileInput").value;
	if(fileVerify != ""){
		var getDatabutton = document.getElementById("getData");
		getDatabutton.innerHTML='<i class="fa fa-spinner fa-spin"></i> Getting Data....';
	}
}
